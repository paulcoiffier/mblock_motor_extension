# Extension MBlock contrôle de moteur
Extension pour le contrôle de moteurs avec la shield DK Electronics Arduino pour l'IDE MBlock
<br /><br />
Pour l'installer, importer l'extension dans son format zip (dans le dossier <strong>"dist"</strong> -> <strong>"Controlleur moteur.zip"</strong>) depuis le gestionnaire d'extensions MBlock.
